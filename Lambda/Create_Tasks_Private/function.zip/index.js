import dotenv from 'dotenv';
import mysql2 from 'mysql2/promise';  // Use promise-based connection

dotenv.config(); 

const db_config = {
    host: process.env.DB_HOST, 
    user: process.env.DB_USER, 
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME  // Fixed 'name' to 'database' (MySQL uses 'database')
};

export const handler = async (event) => {
    let connection;

    try {
        const { user_id, task_name, task_date, task_time, task_priority, task_completed } = event;

        // Validate input (ensure required fields exist)
        if (!user_id || !task_name || !task_date || !task_time || !task_priority) {
            return {
                statusCode: 400, 
                body: JSON.stringify({ message: "All fields except task_completed are required!" })
            };
        }

        // Connect to MySQL
        connection = await mysql2.createConnection(db_config);

        // ✅ Create the tasks table if it does not exist
        const createTableSQL = `
            CREATE TABLE IF NOT EXISTS tasks (
                task_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                task_name VARCHAR(255) NOT NULL,
                task_date DATE NOT NULL,
                task_time TIME NOT NULL,
                task_priority ENUM('Low', 'Medium', 'High') NOT NULL,
                task_completed BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES accounts(id) ON DELETE CASCADE
            );
        `;
        await connection.execute(createTableSQL);

        // ✅ Insert task into the table
        const insertSQL = `
            INSERT INTO tasks (user_id, task_name, task_date, task_time, task_priority, task_completed) 
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        await connection.execute(insertSQL, [user_id, task_name, task_date, task_time, task_priority, task_completed || false]);

        return {
            statusCode: 200, 
            body: JSON.stringify({ message: "Task successfully inserted into the database!" })
        };

    } catch (error) {
        console.error("Error in Lambda function:", error);
        return {
            statusCode: 500, 
            body: JSON.stringify({ message: "Error in Lambda function", error: error.message })
        };
    } finally {
        if (connection) {
            await connection.end();
        }
    }
};
