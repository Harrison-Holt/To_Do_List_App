import mysql2 from 'mysql2'
import dotenv from 'dotenv'

dotenv.config()

const db_config = {
    host: process.env.DB_HOST, 
    user: process.env.DB_USER, 
    password: process.env.DB_PASSWORD, 
}
export const handler = async (event) => {
    let connection; 

    try {
        connection = await mysql2.createConnection(db_config)

        const db_name = "To-Do-List"; 

        await connection.query(`CREATE DATABASE IF NOT EXISTS \`${db_name}\``)
    
     
        await connection.end()

        return {
            statusCode: 200, 
            body: JSON.stringify({ message: "Database Created!"})
        }
    } catch(error) {
        console.error("Database Creation Problem!", error)

        return {
            statusCode: 500, 
            body: JSON.stringify({ message: "Database Creation Problem!", error: error.message })
        }
    }
} 