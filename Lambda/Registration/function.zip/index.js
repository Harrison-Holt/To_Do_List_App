import { CognitoIdentityProviderClient, ConfirmSignUpCommand, SignUpCommand } from '@aws-sdk/client-cognito-identity-provider';
import mysql2 from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const cognitoClient = new CognitoIdentityProviderClient({ region: process.env.REGION });

import crypto from 'crypto';

function generateSecretHash(username, clientId, clientSecret) {
    return crypto
        .createHmac('sha256', clientSecret)
        .update(username + clientId)
        .digest('base64');
}

const db_config = {
    host: process.env.DB_HOST, 
    user: process.env.DB_USER, 
    password: process.env.DB_PASSWORD, 
    database: process.env.DB_NAME
};

export const handler = async (event) => {
    let connection;

    try {
        const { action, username, email, password, confirmation_code } = JSON.parse(event.body);

        if (!action || !username) {
            return { statusCode: 400, body: JSON.stringify({ message: "Action and Username are required!" }) };
        }

        if (action === 'register') {
            await cognitoClient.send(new SignUpCommand({
                ClientId: process.env.COGNITO_CLIENT_ID, 
                Username: username,
                Password: password, 
                SecretHash: generateSecretHash(username),
                UserAttributes: [{ Name: 'email', Value: email }]
            }));

            connection = await mysql2.createConnection(db_config);
            const insert_sql = `INSERT INTO accounts (username, email) VALUES (?, ?);`;
            await connection.execute(insert_sql, [username, email]);
            await connection.end(); // Close DB connection

            return {
                statusCode: 201, 
                body: JSON.stringify({ message: "User Registration Successful! Check your email for verification code." })
            };

        } else if (action === 'verify') {
            await cognitoClient.send(new ConfirmSignUpCommand({
                ClientId: process.env.COGNITO_CLIENT_ID, 
                Username: username, 
                ConfirmationCode: confirmation_code
            }));

            return {
                statusCode: 200, 
                body: JSON.stringify({ message: "User Verified Successfully!" })
            };

        } else {
            return { statusCode: 400, body: JSON.stringify({ message: "Invalid Action. Use 'register' or 'verify'!" }) };
        }

    } catch (error) {
        console.error("Error:", error);
        return {
            statusCode: 500, 
            body: JSON.stringify({ message: "Error Processing Request", error: error.message })
        };
    }
};
